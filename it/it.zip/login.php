<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include "../config/database_p1.php";

$error = "";

if (isset($_POST['btnMasuk'])) {

    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $sql = "SELECT TOP 1 *
            FROM it_user
            WHERE username = ?
            AND password = ?
            AND status_user = 'active'";

    $params = array(
        $username,
        $password
    );

    $query = sqlsrv_query($conn, $sql, $params);

    if ($query === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    $user = sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC);

    if ($user) {

        session_regenerate_id(true);

        $_SESSION['user_id']      = $user['id'];
        $_SESSION['username']     = $user['username'];
        $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
        $_SESSION['department']   = $user['department'];
        $_SESSION['role']         = $user['role'];
        $_SESSION['module']       = "IT";

        header("Location: dashboard.php");
        exit();

    } else {
        $error = "Username / Password salah atau user tidak aktif";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login IT Project</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        body{
            background:#eef2f7;
            height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;
            font-family:Arial;
        }

        .login-box{
            width:100%;
            max-width:420px;
            background:white;
            padding:40px;
            border-radius:20px;
            box-shadow:0 10px 30px rgba(0,0,0,0.1);
        }

        .title{
            text-align:center;
            margin-bottom:30px;
        }

        .title h2{
            font-weight:bold;
            color:#2563eb;
        }

        .title p{
            color:#64748b;
            font-size:14px;
        }

        .btn-login{
            background:#2563eb;
            border:none;
            padding:12px;
            font-weight:bold;
        }

        .btn-login:hover{
            background:#1d4ed8;
        }

        .info-user{
            font-size:12px;
            color:#64748b;
            margin-top:10px;
            text-align:center;
        }
    </style>
</head>

<body>

<div class="login-box">

    <div class="title">
        <h2>IT PROJECT</h2>
        <p>Monitoring Project & Budgeting</p>
    </div>

    <?php if ($error != "") { ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
    <?php } ?>

    <form method="POST">

        <div class="mb-3">
            <label class="form-label">Username</label>

            <div class="input-group">
                <span class="input-group-text">
                    <i class="bi bi-person"></i>
                </span>

                <input type="text"
                       name="username"
                       class="form-control"
                       autocomplete="off"
                       required>
            </div>
        </div>

        <div class="mb-4">
            <label class="form-label">Password</label>

            <div class="input-group">
                <span class="input-group-text">
                    <i class="bi bi-lock"></i>
                </span>

                <input type="password"
                       name="password"
                       class="form-control"
                       required>
            </div>
        </div>

        <div class="d-grid">
            <button type="submit"
                    name="btnMasuk"
                    class="btn btn-primary btn-login">
                LOGIN
                <i class="bi bi-box-arrow-in-right"></i>
            </button>
        </div>

        <div class="d-grid mt-2">
            <a href="../index.php" class="btn btn-outline-secondary">
                Kembali Portal
            </a>
        </div>

    </form>

    <div class="info-user">
        Login menggunakan user aplikasi yang terdaftar di Management User
    </div>

</div>

</body>
</html>