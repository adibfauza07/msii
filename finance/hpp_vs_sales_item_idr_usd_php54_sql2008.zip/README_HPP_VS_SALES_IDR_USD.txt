PAKET HPP VS SALES PER ITEM - IDR & USD
PHP 5.4 + SQL Server 2008

1. Jalankan sp_hpp_sales_item_idr_usd.sql pada database msData di Plant 1 dan Plant 2.
   Procedure tetap bernama dbo.sp_hpp_sales_item_idr sehingga file PHP lama dapat diganti langsung.

2. Salin hpp_vs_sales_item_idr_usd_php54.php ke folder aplikasi.
   Bisa diganti nama menjadi hpp_vs_sales_item_php54.php atau nama halaman yang sedang dipakai.

FITUR BARU
- Pencarian item grafik memakai autocomplete kode + nama item.
- Tabel pencarian memakai daftar autocomplete yang sama.
- Grafik HPP vs Sales IDR.
- Grafik HPP vs Sales USD.
- Kolom unit, total, margin, dan margin persen untuk IDR dan USD.
- Export Excel mencakup IDR dan USD.

KONVERSI USD
- Transaksi USD dipakai langsung sebagai USD.
- Mata uang lain dikonversi ke IDR dengan CURR_RAT pada tanggal transaksi,
  kemudian dibagi kurs USD pada tanggal yang sama.
- HPP BOM memakai tanggal PO terakhir material sampai akhir periode.

CATATAN
- SQL tidak memakai UNION / UNION ALL.
- Bila kurs atau harga tidak tersedia, kolom Error akan bertambah.
