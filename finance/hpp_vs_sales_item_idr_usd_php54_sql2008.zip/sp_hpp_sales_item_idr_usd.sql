USE [msData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
    dbo.sp_hpp_sales_item_idr
    Target: SQL Server 2008

    Membandingkan HPP dengan Sales per item, tahunan atau bulanan,
    dalam IDR dan USD.

    @group_mode:
      YEARLY  = per item per tahun
      MONTHLY = per item per bulan

    Konversi BOM:
      - Material ITTY_CODE = '02'         : BOM.QTY / 1000
      - Material ITTY_CODE IN ('03','05') : BOM.QTY

    Kurs:
      - Nilai IDR dihitung memakai CURR_RAT pada tanggal transaksi/PO.
      - Nilai USD dihitung langsung bila mata uang USD.
      - Mata uang selain USD dikonversi ke IDR, lalu dibagi kurs USD
        pada tanggal transaksi/PO yang sama.

    Tidak memakai UNION / UNION ALL.
*/
IF OBJECT_ID('dbo.sp_hpp_sales_item_idr', 'P') IS NOT NULL
    DROP PROCEDURE dbo.sp_hpp_sales_item_idr
GO

CREATE PROCEDURE dbo.sp_hpp_sales_item_idr
    @from_date DATETIME,
    @to_date   DATETIME,
    @group_mode VARCHAR(10)
AS
BEGIN
    SET NOCOUNT ON;

    SET @group_mode = UPPER(LTRIM(RTRIM(ISNULL(@group_mode, 'MONTHLY'))));
    IF @group_mode NOT IN ('YEARLY', 'MONTHLY')
        SET @group_mode = 'MONTHLY';

    ;WITH SalesLines AS
    (
        SELECT
            D.DI_DATE,
            P.PART_ID AS ITEM_ID,
            I.ITEM_CODE,
            I.ITEM_NAME,
            CAST(ISNULL(DP.QTY, 0) AS DECIMAL(38, 8)) AS SALES_QTY,

            CAST(
                CASE
                    WHEN APV.CURR_CODE IS NULL
                      OR UPPER(LTRIM(RTRIM(APV.CURR_CODE))) IN ('IDR', 'RP', 'RP.')
                        THEN ISNULL(DP.PART_PRICE, 0)
                    WHEN SALES_RATE.CURR_VRATE IS NOT NULL
                        THEN ISNULL(DP.PART_PRICE, 0) * SALES_RATE.CURR_VRATE
                    ELSE NULL
                END
                AS DECIMAL(38, 8)
            ) AS SALES_UNIT_IDR,

            CAST(
                CASE
                    WHEN UPPER(LTRIM(RTRIM(ISNULL(APV.CURR_CODE, 'IDR')))) = 'USD'
                        THEN ISNULL(DP.PART_PRICE, 0)
                    WHEN USD_RATE.CURR_VRATE IS NULL OR USD_RATE.CURR_VRATE = 0
                        THEN NULL
                    WHEN APV.CURR_CODE IS NULL
                      OR UPPER(LTRIM(RTRIM(APV.CURR_CODE))) IN ('IDR', 'RP', 'RP.')
                        THEN ISNULL(DP.PART_PRICE, 0) / USD_RATE.CURR_VRATE
                    WHEN SALES_RATE.CURR_VRATE IS NOT NULL
                        THEN (ISNULL(DP.PART_PRICE, 0) * SALES_RATE.CURR_VRATE) / USD_RATE.CURR_VRATE
                    ELSE NULL
                END
                AS DECIMAL(38, 10)
            ) AS SALES_UNIT_USD,

            CASE
                WHEN APV.CURR_CODE IS NOT NULL
                 AND UPPER(LTRIM(RTRIM(APV.CURR_CODE))) NOT IN ('IDR', 'RP', 'RP.')
                 AND SALES_RATE.CURR_VRATE IS NULL
                    THEN 1
                WHEN UPPER(LTRIM(RTRIM(ISNULL(APV.CURR_CODE, 'IDR')))) <> 'USD'
                 AND (USD_RATE.CURR_VRATE IS NULL OR USD_RATE.CURR_VRATE = 0)
                    THEN 1
                ELSE 0
            END AS SALES_RATE_ERROR
        FROM dbo.DI AS D
        INNER JOIN dbo.DIPA_PAR AS DP
            ON D.DI_ID = DP.DI_ID
        INNER JOIN dbo.PRICE AS P
            ON DP.PRICE_ID = P.PRICE_ID
        INNER JOIN dbo.ITEMS AS I
            ON P.PART_ID = I.ITEM_ID
        OUTER APPLY
        (
            SELECT TOP (1)
                AP.CURR_CODE
            FROM dbo.ACTIVE_PRICE_VIEW AS AP
            WHERE AP.PRICE_ID = P.PRICE_ID
        ) AS APV
        OUTER APPLY
        (
            SELECT TOP (1)
                CR.CURR_VRATE
            FROM dbo.CURR_RAT AS CR
            WHERE UPPER(LTRIM(RTRIM(CR.CURR_CODE))) = UPPER(LTRIM(RTRIM(APV.CURR_CODE)))
              AND D.DI_DATE >= CR.CURR_SDATE
              AND (D.DI_DATE <= CR.CURR_EDATE OR CR.CURR_EDATE IS NULL)
            ORDER BY CR.CURR_SDATE DESC
        ) AS SALES_RATE
        OUTER APPLY
        (
            SELECT TOP (1)
                CR.CURR_VRATE
            FROM dbo.CURR_RAT AS CR
            WHERE UPPER(LTRIM(RTRIM(CR.CURR_CODE))) = 'USD'
              AND D.DI_DATE >= CR.CURR_SDATE
              AND (D.DI_DATE <= CR.CURR_EDATE OR CR.CURR_EDATE IS NULL)
            ORDER BY CR.CURR_SDATE DESC
        ) AS USD_RATE
        WHERE D.DI_DATE >= @from_date
          AND D.DI_DATE < DATEADD(SECOND, 1, @to_date)
          AND P.PART_ID IS NOT NULL
    ),
    SalesPrepared AS
    (
        SELECT
            CASE
                WHEN @group_mode = 'YEARLY'
                    THEN YEAR(SL.DI_DATE)
                ELSE YEAR(SL.DI_DATE) * 100 + MONTH(SL.DI_DATE)
            END AS PERIOD_KEY,
            CASE
                WHEN @group_mode = 'YEARLY'
                    THEN DATEADD(YEAR, DATEDIFF(YEAR, 0, SL.DI_DATE), 0)
                ELSE DATEADD(MONTH, DATEDIFF(MONTH, 0, SL.DI_DATE), 0)
            END AS PERIOD_START,
            SL.ITEM_ID,
            SL.ITEM_CODE,
            SL.ITEM_NAME,
            SL.SALES_QTY,
            SL.SALES_UNIT_IDR,
            SL.SALES_UNIT_USD,
            SL.SALES_RATE_ERROR
        FROM SalesLines AS SL
    ),
    PeriodSales AS
    (
        SELECT
            SP.PERIOD_KEY,
            SP.PERIOD_START,
            CASE
                WHEN @group_mode = 'YEARLY'
                    THEN DATEADD(SECOND, -1, DATEADD(YEAR, 1, SP.PERIOD_START))
                ELSE DATEADD(SECOND, -1, DATEADD(MONTH, 1, SP.PERIOD_START))
            END AS NATURAL_PERIOD_END,
            SP.ITEM_ID,
            SP.ITEM_CODE,
            SP.ITEM_NAME,
            CAST(SUM(SP.SALES_QTY) AS DECIMAL(38, 8)) AS SALES_QTY,
            CAST(
                SUM(
                    CASE
                        WHEN SP.SALES_UNIT_IDR IS NULL THEN 0
                        ELSE SP.SALES_QTY * SP.SALES_UNIT_IDR
                    END
                ) AS DECIMAL(38, 2)
            ) AS TOTAL_SALES_IDR,
            CAST(
                SUM(
                    CASE
                        WHEN SP.SALES_UNIT_USD IS NULL THEN 0
                        ELSE SP.SALES_QTY * SP.SALES_UNIT_USD
                    END
                ) AS DECIMAL(38, 6)
            ) AS TOTAL_SALES_USD,
            SUM(SP.SALES_RATE_ERROR) AS SALES_RATE_ERROR_LINES
        FROM SalesPrepared AS SP
        GROUP BY
            SP.PERIOD_KEY,
            SP.PERIOD_START,
            SP.ITEM_ID,
            SP.ITEM_CODE,
            SP.ITEM_NAME
    ),
    PeriodSalesWithEnd AS
    (
        SELECT
            PS.PERIOD_KEY,
            PS.PERIOD_START,
            CASE
                WHEN PS.NATURAL_PERIOD_END > @to_date THEN @to_date
                ELSE PS.NATURAL_PERIOD_END
            END AS PERIOD_END,
            PS.ITEM_ID,
            PS.ITEM_CODE,
            PS.ITEM_NAME,
            PS.SALES_QTY,
            PS.TOTAL_SALES_IDR,
            PS.TOTAL_SALES_USD,
            PS.SALES_RATE_ERROR_LINES
        FROM PeriodSales AS PS
    )
    SELECT
        PS.PERIOD_KEY,
        YEAR(PS.PERIOD_START) AS SALES_YEAR,
        CASE WHEN @group_mode = 'MONTHLY' THEN MONTH(PS.PERIOD_START) ELSE 0 END AS SALES_MONTH,
        PS.PERIOD_START,
        PS.PERIOD_END,
        PS.ITEM_ID,
        PS.ITEM_CODE,
        PS.ITEM_NAME,
        CAST(PS.SALES_QTY AS DECIMAL(38, 6)) AS SALES_QTY,

        CAST(HPP_FINAL.HPP_UNIT_IDR AS DECIMAL(38, 6)) AS HPP_UNIT_IDR,
        CAST(
            CASE
                WHEN ISNULL(PS.SALES_QTY, 0) = 0 THEN 0
                ELSE PS.TOTAL_SALES_IDR / PS.SALES_QTY
            END AS DECIMAL(38, 6)
        ) AS SALES_UNIT_IDR,
        CAST(HPP_FINAL.HPP_UNIT_USD AS DECIMAL(38, 8)) AS HPP_UNIT_USD,
        CAST(
            CASE
                WHEN ISNULL(PS.SALES_QTY, 0) = 0 THEN 0
                ELSE PS.TOTAL_SALES_USD / PS.SALES_QTY
            END AS DECIMAL(38, 8)
        ) AS SALES_UNIT_USD,

        CAST(PS.SALES_QTY * HPP_FINAL.HPP_UNIT_IDR AS DECIMAL(38, 2)) AS TOTAL_HPP_IDR,
        CAST(PS.TOTAL_SALES_IDR AS DECIMAL(38, 2)) AS TOTAL_SALES_IDR,
        CAST(
            PS.TOTAL_SALES_IDR - (PS.SALES_QTY * HPP_FINAL.HPP_UNIT_IDR)
            AS DECIMAL(38, 2)
        ) AS MARGIN_IDR,
        CAST(
            CASE
                WHEN ISNULL(PS.TOTAL_SALES_IDR, 0) = 0 THEN NULL
                ELSE
                    (
                        PS.TOTAL_SALES_IDR - (PS.SALES_QTY * HPP_FINAL.HPP_UNIT_IDR)
                    ) / PS.TOTAL_SALES_IDR * 100.0
            END AS DECIMAL(18, 4)
        ) AS MARGIN_PERCENT,

        CAST(PS.SALES_QTY * HPP_FINAL.HPP_UNIT_USD AS DECIMAL(38, 6)) AS TOTAL_HPP_USD,
        CAST(PS.TOTAL_SALES_USD AS DECIMAL(38, 6)) AS TOTAL_SALES_USD,
        CAST(
            PS.TOTAL_SALES_USD - (PS.SALES_QTY * HPP_FINAL.HPP_UNIT_USD)
            AS DECIMAL(38, 6)
        ) AS MARGIN_USD,
        CAST(
            CASE
                WHEN ISNULL(PS.TOTAL_SALES_USD, 0) = 0 THEN NULL
                ELSE
                    (
                        PS.TOTAL_SALES_USD - (PS.SALES_QTY * HPP_FINAL.HPP_UNIT_USD)
                    ) / PS.TOTAL_SALES_USD * 100.0
            END AS DECIMAL(18, 4)
        ) AS MARGIN_PERCENT_USD,

        HPP_FINAL.HPP_SOURCE,
        ISNULL(HPP_FINAL.HPP_ERROR_LINES, 0) AS HPP_ERROR_LINES,
        ISNULL(PS.SALES_RATE_ERROR_LINES, 0) AS SALES_RATE_ERROR_LINES,
        ISNULL(HPP_FINAL.HPP_ERROR_LINES, 0) + ISNULL(PS.SALES_RATE_ERROR_LINES, 0) AS ERROR_LINES
    FROM PeriodSalesWithEnd AS PS

    OUTER APPLY
    (
        SELECT
            COUNT(BOM_DETAIL.MATERIAL_ID) AS BOM_LINES,
            CAST(SUM(ISNULL(BOM_DETAIL.MATERIAL_COST_IDR, 0)) AS DECIMAL(38, 8)) AS BOM_HPP_UNIT_IDR,
            CAST(SUM(ISNULL(BOM_DETAIL.MATERIAL_COST_USD, 0)) AS DECIMAL(38, 10)) AS BOM_HPP_UNIT_USD,
            SUM(BOM_DETAIL.ERROR_LINE) AS BOM_ERROR_LINES
        FROM
        (
            SELECT
                BD.ITEM_ID AS MATERIAL_ID,
                CAST(
                    CASE
                        WHEN LTRIM(RTRIM(MI.ITTY_CODE)) = '02'
                            THEN ISNULL(BD.QTY, 0) / 1000.0
                        ELSE ISNULL(BD.QTY, 0)
                    END
                    *
                    CASE
                        WHEN LP.POD_PRICE IS NULL THEN 0
                        WHEN LP.PO_CUR IS NULL
                          OR UPPER(LTRIM(RTRIM(LP.PO_CUR))) IN ('IDR', 'RP', 'RP.')
                            THEN LP.POD_PRICE
                        WHEN MAT_RATE.CURR_VRATE IS NOT NULL
                            THEN LP.POD_PRICE * MAT_RATE.CURR_VRATE
                        ELSE 0
                    END
                    AS DECIMAL(38, 8)
                ) AS MATERIAL_COST_IDR,
                CAST(
                    CASE
                        WHEN LTRIM(RTRIM(MI.ITTY_CODE)) = '02'
                            THEN ISNULL(BD.QTY, 0) / 1000.0
                        ELSE ISNULL(BD.QTY, 0)
                    END
                    *
                    CASE
                        WHEN LP.POD_PRICE IS NULL THEN 0
                        WHEN UPPER(LTRIM(RTRIM(ISNULL(LP.PO_CUR, 'IDR')))) = 'USD'
                            THEN LP.POD_PRICE
                        WHEN MAT_USD_RATE.CURR_VRATE IS NULL OR MAT_USD_RATE.CURR_VRATE = 0
                            THEN 0
                        WHEN LP.PO_CUR IS NULL
                          OR UPPER(LTRIM(RTRIM(LP.PO_CUR))) IN ('IDR', 'RP', 'RP.')
                            THEN LP.POD_PRICE / MAT_USD_RATE.CURR_VRATE
                        WHEN MAT_RATE.CURR_VRATE IS NOT NULL
                            THEN (LP.POD_PRICE * MAT_RATE.CURR_VRATE) / MAT_USD_RATE.CURR_VRATE
                        ELSE 0
                    END
                    AS DECIMAL(38, 10)
                ) AS MATERIAL_COST_USD,
                CASE
                    WHEN LP.POD_PRICE IS NULL THEN 1
                    WHEN LP.PO_CUR IS NOT NULL
                     AND UPPER(LTRIM(RTRIM(LP.PO_CUR))) NOT IN ('IDR', 'RP', 'RP.')
                     AND MAT_RATE.CURR_VRATE IS NULL THEN 1
                    WHEN UPPER(LTRIM(RTRIM(ISNULL(LP.PO_CUR, 'IDR')))) <> 'USD'
                     AND (MAT_USD_RATE.CURR_VRATE IS NULL OR MAT_USD_RATE.CURR_VRATE = 0) THEN 1
                    ELSE 0
                END AS ERROR_LINE
            FROM dbo.BOM_DEFAULT AS BD
            INNER JOIN dbo.ITEMS AS MI
                ON BD.ITEM_ID = MI.ITEM_ID
            OUTER APPLY
            (
                SELECT TOP (1)
                    PO.PO_DATE,
                    PO.PO_CUR,
                    PD.POD_PRICE
                FROM dbo.PO_DETAIL AS PD
                INNER JOIN dbo.PO AS PO
                    ON PD.PO_ID = PO.PO_ID
                WHERE PD.ITEM_ID = BD.ITEM_ID
                  AND PO.PO_DATE < DATEADD(SECOND, 1, PS.PERIOD_END)
                ORDER BY PO.PO_DATE DESC, PO.PO_ID DESC
            ) AS LP
            OUTER APPLY
            (
                SELECT TOP (1)
                    CR.CURR_VRATE
                FROM dbo.CURR_RAT AS CR
                WHERE UPPER(LTRIM(RTRIM(CR.CURR_CODE))) = UPPER(LTRIM(RTRIM(LP.PO_CUR)))
                  AND LP.PO_DATE >= CR.CURR_SDATE
                  AND (LP.PO_DATE <= CR.CURR_EDATE OR CR.CURR_EDATE IS NULL)
                ORDER BY CR.CURR_SDATE DESC
            ) AS MAT_RATE
            OUTER APPLY
            (
                SELECT TOP (1)
                    CR.CURR_VRATE
                FROM dbo.CURR_RAT AS CR
                WHERE UPPER(LTRIM(RTRIM(CR.CURR_CODE))) = 'USD'
                  AND LP.PO_DATE >= CR.CURR_SDATE
                  AND (LP.PO_DATE <= CR.CURR_EDATE OR CR.CURR_EDATE IS NULL)
                ORDER BY CR.CURR_SDATE DESC
            ) AS MAT_USD_RATE
            WHERE BD.PART_ID = PS.ITEM_ID
              AND LTRIM(RTRIM(MI.ITTY_CODE)) IN ('02', '03', '05')
        ) AS BOM_DETAIL
    ) AS BOM_COST

    OUTER APPLY
    (
        SELECT TOP (1)
            PO.PO_DATE,
            PO.PO_CUR,
            PD.POD_PRICE
        FROM dbo.PO_DETAIL AS PD
        INNER JOIN dbo.PO AS PO
            ON PD.PO_ID = PO.PO_ID
        WHERE PD.ITEM_ID = PS.ITEM_ID
          AND PO.PO_DATE < DATEADD(SECOND, 1, PS.PERIOD_END)
        ORDER BY PO.PO_DATE DESC, PO.PO_ID DESC
    ) AS FINISHED_PO
    OUTER APPLY
    (
        SELECT TOP (1)
            CR.CURR_VRATE
        FROM dbo.CURR_RAT AS CR
        WHERE UPPER(LTRIM(RTRIM(CR.CURR_CODE))) = UPPER(LTRIM(RTRIM(FINISHED_PO.PO_CUR)))
          AND FINISHED_PO.PO_DATE >= CR.CURR_SDATE
          AND (FINISHED_PO.PO_DATE <= CR.CURR_EDATE OR CR.CURR_EDATE IS NULL)
        ORDER BY CR.CURR_SDATE DESC
    ) AS FINISHED_RATE
    OUTER APPLY
    (
        SELECT TOP (1)
            CR.CURR_VRATE
        FROM dbo.CURR_RAT AS CR
        WHERE UPPER(LTRIM(RTRIM(CR.CURR_CODE))) = 'USD'
          AND FINISHED_PO.PO_DATE >= CR.CURR_SDATE
          AND (FINISHED_PO.PO_DATE <= CR.CURR_EDATE OR CR.CURR_EDATE IS NULL)
        ORDER BY CR.CURR_SDATE DESC
    ) AS FINISHED_USD_RATE
    OUTER APPLY
    (
        SELECT
            CAST(
                CASE
                    WHEN ISNULL(BOM_COST.BOM_LINES, 0) > 0
                        THEN ISNULL(BOM_COST.BOM_HPP_UNIT_IDR, 0)
                    WHEN FINISHED_PO.POD_PRICE IS NULL
                        THEN 0
                    WHEN FINISHED_PO.PO_CUR IS NULL
                      OR UPPER(LTRIM(RTRIM(FINISHED_PO.PO_CUR))) IN ('IDR', 'RP', 'RP.')
                        THEN FINISHED_PO.POD_PRICE
                    WHEN FINISHED_RATE.CURR_VRATE IS NOT NULL
                        THEN FINISHED_PO.POD_PRICE * FINISHED_RATE.CURR_VRATE
                    ELSE 0
                END AS DECIMAL(38, 8)
            ) AS HPP_UNIT_IDR,
            CAST(
                CASE
                    WHEN ISNULL(BOM_COST.BOM_LINES, 0) > 0
                        THEN ISNULL(BOM_COST.BOM_HPP_UNIT_USD, 0)
                    WHEN FINISHED_PO.POD_PRICE IS NULL
                        THEN 0
                    WHEN UPPER(LTRIM(RTRIM(ISNULL(FINISHED_PO.PO_CUR, 'IDR')))) = 'USD'
                        THEN FINISHED_PO.POD_PRICE
                    WHEN FINISHED_USD_RATE.CURR_VRATE IS NULL OR FINISHED_USD_RATE.CURR_VRATE = 0
                        THEN 0
                    WHEN FINISHED_PO.PO_CUR IS NULL
                      OR UPPER(LTRIM(RTRIM(FINISHED_PO.PO_CUR))) IN ('IDR', 'RP', 'RP.')
                        THEN FINISHED_PO.POD_PRICE / FINISHED_USD_RATE.CURR_VRATE
                    WHEN FINISHED_RATE.CURR_VRATE IS NOT NULL
                        THEN (FINISHED_PO.POD_PRICE * FINISHED_RATE.CURR_VRATE) / FINISHED_USD_RATE.CURR_VRATE
                    ELSE 0
                END AS DECIMAL(38, 10)
            ) AS HPP_UNIT_USD,
            CAST(
                CASE
                    WHEN ISNULL(BOM_COST.BOM_LINES, 0) > 0 THEN 'BOM_MATERIAL'
                    WHEN FINISHED_PO.POD_PRICE IS NOT NULL THEN 'PO_FINISHED_ITEM'
                    ELSE 'TANPA_HPP'
                END AS VARCHAR(30)
            ) AS HPP_SOURCE,
            CASE
                WHEN ISNULL(BOM_COST.BOM_LINES, 0) > 0
                    THEN ISNULL(BOM_COST.BOM_ERROR_LINES, 0)
                WHEN FINISHED_PO.POD_PRICE IS NULL
                    THEN 1
                WHEN FINISHED_PO.PO_CUR IS NOT NULL
                 AND UPPER(LTRIM(RTRIM(FINISHED_PO.PO_CUR))) NOT IN ('IDR', 'RP', 'RP.')
                 AND FINISHED_RATE.CURR_VRATE IS NULL
                    THEN 1
                WHEN UPPER(LTRIM(RTRIM(ISNULL(FINISHED_PO.PO_CUR, 'IDR')))) <> 'USD'
                 AND (FINISHED_USD_RATE.CURR_VRATE IS NULL OR FINISHED_USD_RATE.CURR_VRATE = 0)
                    THEN 1
                ELSE 0
            END AS HPP_ERROR_LINES
    ) AS HPP_FINAL

    ORDER BY
        PS.PERIOD_KEY,
        PS.ITEM_CODE;
END
GO

/* Tahunan:
EXEC dbo.sp_hpp_sales_item_idr
    @from_date = '2024-01-01',
    @to_date = '2026-12-31 23:59:59',
    @group_mode = 'YEARLY';
*/

/* Bulanan:
EXEC dbo.sp_hpp_sales_item_idr
    @from_date = '2026-01-01',
    @to_date = '2026-12-31 23:59:59',
    @group_mode = 'MONTHLY';
*/
